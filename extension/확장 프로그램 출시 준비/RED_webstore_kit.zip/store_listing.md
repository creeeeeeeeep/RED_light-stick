# RED 응원봉 — 크롬 웹스토어 리스팅 자료

> 대시보드에 그대로 붙여넣는 용도. 글자수 제한에 맞춰 뒀다.

---

## 1. 기본 정보

| 항목 | 값 |
|---|---|
| **확장 이름** (≤45자) | `RED 응원봉 — 치지직 응원 도우미` |
| **요약** (≤132자) | `레드RED 팬메이드 응원봉과 연동됩니다. 봉을 흔들면 치지직 채팅창에 응원 이모티콘이 채워지고, 버튼을 눌러야만 전송됩니다. 자동 전송 없음.` |
| **카테고리** | 소셜 & 커뮤니케이션 |
| **언어** | 한국어 (기본) · English |
| **공개 범위** | **비공개 링크 (Unlisted)** |
| **가격** | 무료 |
| **아이콘** | `icon128_padded.png` |
| **소형 프로모 타일** | `promo_440x280.png` |
| **스크린샷** | 1280×800 PNG 1~5장 — **동작하는 빌드에서 실제 화면** (코더) |

---

## 2. 상세 설명 (한국어)

```
레드RED 팬메이드 응원봉 전용 확장 프로그램입니다.

■ 하는 일
응원봉(ESP32 · 같은 와이파이)을 흔들면 치지직 채팅 입력창에 응원 이모티콘이 채워집니다.
전송은 응원봉의 버튼을 사람이 직접 눌렀을 때만 됩니다.

■ 자동 전송이 없는 이유
이 확장은 매크로가 아닙니다. 흔들기는 '입력'만 하고, '전송'은 반드시 사용자의 버튼 조작이 필요합니다.
전송 후 3초 쿨다운이 있고, 같은 이모티콘이 연속으로 쌓이지 않도록 제한합니다.
치지직 이용약관과 활동 제한 정책을 지키기 위한 설계입니다.

■ 동작 방식
· 응원봉이 같은 와이파이 안에서 WebSocket 서버(red-stick.local:81)로 동작합니다.
· 확장은 그 서버에 연결해 "흔들림 / 버튼" 신호를 받습니다.
· 신호를 받으면 chzzk.naver.com 채팅 입력창에 이모티콘 토큰을 넣거나, 입력창 내용을 전송합니다.
· 그 외에는 아무것도 하지 않습니다.

■ 수집하는 정보
없습니다. 이 확장은 어떤 데이터도 외부로 보내지 않습니다.
설정(응원봉 토큰, 이벤트 시간창)은 브라우저 안에만 저장됩니다.

■ 필요한 것
· RED 응원봉 (팬메이드 · 비매품)
· 응원봉과 같은 와이파이에 연결된 PC
· 치지직 로그인

■ 팬메이드 · 비영리
레드RED 팬이 만든 비공식 프로젝트입니다. 이모티콘은 레드RED 의 허락을 받아 사용합니다.
네이버·치지직과 무관합니다.
```

## 3. Description (English)

```
Companion extension for the fan-made RED light stick.

WHAT IT DOES
Shake the light stick (ESP32, same Wi-Fi) and a cheer emoticon is typed into the CHZZK chat box.
Sending happens ONLY when a person presses the physical button on the stick.

NOT A MACRO
Shaking only fills the input. Sending always requires a deliberate button press.
A 3-second cooldown applies after each send, and repeated emoticons are capped.
This design respects CHZZK's terms and anti-spam policy.

HOW IT WORKS
· The stick runs a WebSocket server on the local network (red-stick.local:81).
· The extension connects to it and receives "shake" / "button" signals.
· On a signal it inserts an emoticon token into the chat box on chzzk.naver.com, or sends the current input.
· Nothing else.

DATA
None collected. Nothing leaves your browser. Settings (stick token, event time window) are stored locally.

REQUIREMENTS
· RED light stick (fan-made, not for sale)
· PC on the same Wi-Fi as the stick
· Logged in to CHZZK

Unofficial fan project. Emoticons used with permission from RED. Not affiliated with NAVER / CHZZK.
```

---

## 4. 권한 사유 (대시보드 "권한 정당성" 칸)

| 권한 | 사유 (그대로 붙여넣기) |
|---|---|
| `host_permissions: *://chzzk.naver.com/*` | 치지직 방송 페이지의 채팅 입력창에 이모티콘을 넣고, 사용자가 버튼을 눌렀을 때 전송하기 위해 필요합니다. 다른 사이트에서는 동작하지 않습니다. |
| `storage` | 응원봉 연결 토큰과 이벤트 시간창 설정을 브라우저 안에 저장합니다. 외부 전송 없음. |
| 백그라운드 서비스워커의 WebSocket (`ws://red-stick.local:81`) | 같은 네트워크 안의 응원봉 장치와 통신하기 위해 필요합니다. 인터넷 서버와는 통신하지 않습니다. |
| **단일 목적** | RED 응원봉 장치의 흔들기·버튼 신호를 치지직 채팅 입력에 연결하는 것. |
| **원격 코드** | 사용하지 않음. |

> `tabs`, `scripting`, `<all_urls>`, `webRequest` 는 **쓰지 말 것.** 심사가 길어지고 거절 사유가 된다.

---

## 5. 개인정보 섹션 (대시보드 "개인정보 보호 관행")

- 데이터 수집 : **없음** (모든 항목 체크 해제)
- "이 확장은 사용자 데이터를 수집하거나 사용하지 않습니다" 선언 체크
- "판매하지 않음 / 승인된 목적 외 사용 안 함 / 신용도 판단에 사용 안 함" 3개 체크
- 개인정보처리방침 URL : `privacy_policy.html` 을 깃허브 페이지에 올린 주소

---

## 6. manifest.json 체크리스트 (코더)

```json
{
  "manifest_version": 3,
  "name": "RED 응원봉 — 치지직 응원 도우미",
  "version": "1.0.0",
  "description": "레드RED 팬메이드 응원봉 연동. 흔들면 입력, 버튼을 눌러야 전송. 자동 전송 없음.",
  "icons": { "16": "icon16.png", "32": "icon32.png", "48": "icon48.png", "128": "icon128.png" },
  "action": { "default_icon": { "16": "icon16.png", "32": "icon32.png" }, "default_popup": "popup.html" },
  "permissions": ["storage"],
  "host_permissions": ["*://chzzk.naver.com/*"],
  "background": { "service_worker": "sw.js" },
  "content_scripts": [{ "matches": ["*://chzzk.naver.com/live/*"], "js": ["content.js"] }]
}
```

- [ ] `manifest_version: 3`
- [ ] 권한은 위 둘뿐
- [ ] 원격 스크립트 로드 없음 (CDN 금지, 전부 zip 안에)
- [ ] 난독화 없음 (심사 거절 사유)
- [ ] `ws://` 연결은 **서비스워커**에서만
- [ ] 자동 전송 코드 경로가 **존재하지 않음** (설정으로도 못 켜게)
- [ ] 쿨다운 3초 · 연속 토큰 상한 5
- [ ] zip 최상위에 manifest.json (폴더 안에 넣지 말 것)

---

## 7. 제출 순서 (정수)

1. [chrome.google.com/webstore/devconsole](https://chrome.google.com/webstore/devconsole) → 구글 로그인 → 개발자 등록 **$5** 결제 (계정에 2단계 인증 필요)
2. "새 항목" → 코더가 준 **zip 업로드**
3. **스토어 등록정보** 탭 : 위 1·2·3 붙여넣기, 아이콘·프로모·스크린샷 업로드
4. **개인정보 보호 관행** 탭 : 위 4·5 붙여넣기
5. **배포** 탭 : 공개 범위 **비공개 링크(Unlisted)**, 국가 전체
6. "검토를 위해 제출"
7. 심사 1~3일. 승인 메일 오면 링크 복사 → 팬 30명에게 전달

**거절되면** : 거절 사유 메일을 그대로 보내주시면 답변문 써드립니다. 대부분 권한 사유 보강이나 설명 수정으로 통과됩니다.
